function despedirse() #Muestra un mensaje de despedida para el usuario
{
	dialog --backtitle "Agenda 2012 - ISO" --title "Agenda" \
			--msgbox "Que tengas un buen dia\n\nPrograma creado por:\n\
Arkaitz Duro\nDavid Espino\nAlexander Mariel" 10 50
}
