function bukatu(){
dialog --msgbox "Irten aukera sakatu duzu, programa amaitu da\n" 5 50	#Programa bukaera
}
